package org.example;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;

import java.io.IOException;
import java.util.Arrays;

public class Screen {
    public static final TextColor
            WHITE = new TextColor.RGB(255,255,255),
            BLACK = new TextColor.RGB(0,0,0),
            BLUE = new TextColor.RGB(0,0,255),
            YELLOW = new TextColor.RGB(255,255,0),
            GREEN = new TextColor.RGB(0,255,0),
            RED = new TextColor.RGB(255,0,0);

    private DefaultTerminalFactory terminalFactory = new DefaultTerminalFactory();
    private Terminal terminal;

    public char [][] array =new char[80][24];

    public Screen(){
        try{
            terminal = terminalFactory.createTerminal();
            terminal.setCursorVisible(false);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public void putChar(int x, int y, char c) throws IOException {
        terminal.setCursorPosition(x,y);
/*          terminal.setForegroundColor(YELLOW);
        terminal.setBackgroundColor(BLACK);*/
        terminal.putCharacter(c);
        array[x-1][y-1] =c;
        terminal.flush();
    }

    public void screenWithDots() throws IOException {
        int x, y;
        x = terminal.getTerminalSize().getColumns();
        y = terminal.getTerminalSize().getRows();
        for (int i = 0; i < x; i++){
            for(int j = 0; j < y; j++){
                terminal.setCursorPosition(i, j);
                terminal.putCharacter('.');
                /*terminal.setForegroundColor(RED);
                terminal.setBackgroundColor(BLACK);*/
                terminal.flush();
            }
        }
    }
    public Positions[] obstacle(int x, int y) throws IOException {
        int obstacleWidth = 4;
        char obstacleBlock= '\u2588';
        Positions[] positionArray= new Positions[obstacleWidth];
        for(int i =0 ; i < obstacleWidth ;i++)
        {
            Positions p = new Positions(x+i,y);
            positionArray[i]=p;
            putChar(p.getPx(), p.getPy(),obstacleBlock);
        }
        return positionArray;
    }
    public KeyStroke getInput() throws IOException {
        return terminal.pollInput();
    }
    public void close() throws IOException{
        terminal.close();
    }

    public char getChar(int col, int row){

        return array[col-1][row-1];

    }
 /*  public void border() throws IOException {
        char BLOCK = '\u2588';
        for (int row = 0; row < 24; row++) {
            putChar(0, row, BLOCK);
            putChar(79, row, BLOCK);

        }
        for (int col = 0; col < 80; col++) {
            putChar(col, 0, BLOCK);
            putChar(col, 23, BLOCK);
        }*/
    }

