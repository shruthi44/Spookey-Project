package org.example;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        Screen screen = new Screen();
        Spooky spooky = new Spooky(screen);
        screen.screenWithDots();
        //screen.border();
        int[] obstacleArrayX= new int[]{10,25,50,70};
        int[] obstacleArrayY= new int[]{5,15,10,22};
        Positions[] positions = new Positions[4];

        for(int i=0; i< obstacleArrayX.length;i++){
            for(int j=0; j< obstacleArrayX.length;j++){
                positions = screen.obstacle(obstacleArrayX[i], obstacleArrayY[j]);
            }

        }
        spooky.spookyMovement(40,11,spooky.getSpooky(),positions);

    }
}