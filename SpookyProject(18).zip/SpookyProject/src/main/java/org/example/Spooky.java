package org.example;

import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;

import java.io.IOException;
import java.util.Arrays;

public class Spooky {
    private final char spooky;
    private Screen screen;

    public Spooky(Screen screen) throws IOException {
        this.spooky = '\u2620';
        this.screen = screen;
    }
    public char getSpooky() {
        return spooky;
    }

    public void spookyMovement(int x, int y, char c,Positions[] positions) throws IOException, InterruptedException {
        boolean continueReadingInput = true;

        screen.putChar(40, 11, spooky);

        while (continueReadingInput) {
            KeyStroke keyStroke = null;
            do {
                Thread.sleep(5); // might throw InterruptedException
                keyStroke = screen.getInput();
            } while (keyStroke == null);

            KeyType type = keyStroke.getKeyType();
            if (type == KeyType.Character) {
                continueReadingInput = false;
                System.out.println("quit");
                screen.close();
            }
            int oldX = x; // save old position x
            int oldY = y; // save old position y
            switch (keyStroke.getKeyType()) {
                case ArrowDown:
                    y += 1;
                    break;
                case ArrowUp:
                    y -= 1;
                    break;
                case ArrowRight:
                    x += 1;
                    break;
                case ArrowLeft:
                    x -= 1;
                    break;
            }


            for(Positions p :positions ) {
                char c1 = screen.getChar(p.getPx(),p.getPy());
                char c2 = screen.getChar(x,y);
                System.out.println("before obstacle");
                if (c1 == c2) {
                    x = oldX;
                    y = oldY;
                    System.out.println("At the obstacle");
                }
            }
            screen.putChar(oldX, oldY, ' ');
            screen.putChar(x, y, spooky);
            System.out.println("after obstacle2");
        }
    }

}


